# Architecture decisions

## Trust model

**Source partner:** receives sender fiat, performs on-ramp, funds exact USDC.
**Compliance signer:** separate operational key/service. It cannot redirect funds; it can approve/reject/freeze.
**Destination partner:** accepts payout obligation before receiving USDC.
**Contract:** holds USDC and enforces state transitions.
**CrossTrade Laravel:** orchestration, PII, quote, KYC, partner APIs, reconciliation, notifications.

## Monitoring layers

1. **Stellar network observation** — RPC `getEvents` unified transfer events and contract events.
2. **Transaction rules** — amount, velocity, corridor, partner, duplicate/replay, unusual behavior.
3. **KYT/sanctions** — external licensed data provider(s); results stay off-chain.
4. **On-chain control** — approve/reject/freeze attestation from dedicated signer.
5. **Post-release reconciliation** — verify destination USDC receipt and local-fiat payout reference.

## Why no automatic payout from a monitoring event?

Events are observations, not trusted compliance decisions. Auto-release should occur only after an authenticated compliance attestation and destination acceptance. This prevents a compromised web backend or spoofed callback from releasing escrow.

## Payout finality caveat

The Soroban contract can prove that USDC was released to the destination partner. It cannot prove that a bank/mobile-money beneficiary received local fiat. That last-mile proof belongs to the partner API + reconciliation system. Store its receipt off-chain and optionally anchor a hash in a later contract extension.
