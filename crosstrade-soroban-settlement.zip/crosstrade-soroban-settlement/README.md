# CrossTrade Soroban Cross-Border Settlement Escrow

## What this contract is for

The strongest Soroban use case in CrossTrade is **not escrowing fiat**. Fiat remains in regulated bank/payment-partner accounts. Soroban becomes the programmable settlement escrow **after source fiat has been received and converted into Stellar USDC**.

Recommended corridor:

`Sender fiat → source LP/anchor → USDC on Stellar → Soroban escrow → compliance approval + destination LP acceptance → destination LP → local fiat payout → beneficiary`

The contract makes the middle leg deterministic and auditable: the destination partner cannot receive the USDC until screening is approved and it has accepted the payout obligation; expired/rejected settlements return USDC to the source partner.

## Why this is better than a simple USDC transfer

- Conditional delivery versus blind transfer.
- On-chain state for funded / screened / accepted / released / refunded / frozen / disputed.
- Separation of duties: source partner funds; independent compliance signer approves; destination partner accepts.
- Timeout refunds prevent indefinite custody.
- Hashes bind the settlement to quote, beneficiary reference and compliance evidence without publishing PII.
- Contract events feed the monitoring/audit pipeline.

## Important Stellar monitoring distinction

Stellar's unified events/RPC payment monitoring is a **data/observability mechanism**, not an on-chain AML oracle. A Soroban contract cannot call a sanctions API or scan arbitrary historic transactions. CrossTrade should run an off-chain monitoring worker that consumes Stellar RPC events, performs KYC/KYT/sanctions/velocity rules, stores evidence, and then signs an on-chain `compliance_decision` or `freeze` call.

Do not put names, bank details, identity documents, sanctions results, or provider payloads on-chain. Store only opaque IDs/hashes.

## Contract lifecycle

1. `create` — source partner commits immutable settlement terms and exact USDC amount.
2. Source fiat is received and converted off-chain.
3. `fund` — source partner transfers USDC into the contract.
4. Monitoring service observes the transfer/event and screens the transaction.
5. `compliance_decision` — dedicated signer records approve/reject + evidence hash.
6. `accept_destination` — destination LP confirms it can honor the off-ramp/payout.
7. `release` — contract transfers escrowed USDC to destination LP.
8. Laravel/partner rails off-ramp and mark beneficiary payout complete off-chain.
9. Rejected settlement: `refund_rejected`. Expired funded settlement: `refund_expired`.

## Production hardening before Mainnet

This is production-oriented source, **not an audited contract**. Before Mainnet: independent audit; invariant/property tests; fuzzing; Testnet soak; multisig/contract-account admin; HSM/MPC for compliance signer; key rotation runbook; strict USDC SAC allowlist; corridor/partner allowlists; amount caps; replay/idempotency in Laravel; reconciliation against RPC/Horizon/Galexie; incident pause policy; disaster recovery; legal/compliance review per corridor.

A particularly important next hardening step is changing initialization to pin the official Stellar USDC SAC contract ID(s) and reject any unapproved token contract. This reference keeps `token` per settlement so Testnet and multiple regulated settlement assets can be tested.

## Build

Use a current Stellar CLI compatible with Mainnet protocol and Soroban SDK 28, then:

```bash
stellar contract build
cargo test
```

Deploy the generated WASM on Testnet first. Protocol/SDK versions move quickly; verify current Mainnet protocol and CLI/SDK compatibility before building for production.

## CrossTrade app mapping

The supplied CrossTrade prototype currently simulates fiat settlement accounts, Stellar routes and compliance escrow. Replace the simulated settlement step with a Laravel orchestration service that persists the quote/payment first, then invokes this contract only after the source LP confirms fiat receipt + USDC conversion.
