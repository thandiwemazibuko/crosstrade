#![no_std]

use soroban_sdk::{contract, contracterror, contractimpl, contracttype, symbol_short, Address, BytesN, Env, String, Symbol};
use soroban_sdk::token;

#[contracttype]
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum SettlementStatus {
    AwaitingFunding,
    Funded,
    ComplianceApproved,
    ComplianceRejected,
    DestinationAccepted,
    Released,
    Refunded,
    Frozen,
    Disputed,
}

#[contracttype]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Settlement {
    pub id: BytesN<32>,
    pub payer: Address,
    pub source_partner: Address,
    pub destination_partner: Address,
    pub token: Address,
    pub amount: i128,
    pub source_currency: String,
    pub destination_currency: String,
    pub beneficiary_ref: BytesN<32>,
    pub quote_hash: BytesN<32>,
    pub expires_at: u64,
    pub status: SettlementStatus,
    pub funded_at: u64,
    pub compliance_at: u64,
    pub released_at: u64,
}

#[contracttype]
#[derive(Clone)]
pub enum DataKey {
    Admin,
    ComplianceSigner,
    Paused,
    Settlement(BytesN<32>),
}

#[contracterror]
#[derive(Copy, Clone, Debug, Eq, PartialEq, PartialOrd, Ord)]
#[repr(u32)]
pub enum Error {
    AlreadyInitialized = 1,
    NotInitialized = 2,
    AlreadyExists = 3,
    NotFound = 4,
    InvalidAmount = 5,
    InvalidExpiry = 6,
    InvalidState = 7,
    Expired = 8,
    NotExpired = 9,
    Paused = 10,
    Unauthorized = 11,
}

#[contract]
pub struct CrossBorderEscrow;

fn admin(env: &Env) -> Result<Address, Error> {
    env.storage().instance().get(&DataKey::Admin).ok_or(Error::NotInitialized)
}

fn compliance(env: &Env) -> Result<Address, Error> {
    env.storage().instance().get(&DataKey::ComplianceSigner).ok_or(Error::NotInitialized)
}

fn ensure_live(env: &Env) -> Result<(), Error> {
    let paused: bool = env.storage().instance().get(&DataKey::Paused).unwrap_or(false);
    if paused { Err(Error::Paused) } else { Ok(()) }
}

fn read_settlement(env: &Env, id: &BytesN<32>) -> Result<Settlement, Error> {
    env.storage().persistent().get(&DataKey::Settlement(id.clone())).ok_or(Error::NotFound)
}

fn write_settlement(env: &Env, s: &Settlement) {
    let key = DataKey::Settlement(s.id.clone());
    env.storage().persistent().set(&key, s);
    // ~120 days at ~5 sec/ledger. The application should refresh TTL for longer-lived records.
    env.storage().persistent().extend_ttl(&key, 17280, 2_073_600);
}

fn event(env: &Env, topic: Symbol, id: &BytesN<32>, status: SettlementStatus) {
    env.events().publish((symbol_short!("xborder"), topic, id.clone()), status);
}

#[contractimpl]
impl CrossBorderEscrow {
    pub fn initialize(env: Env, admin_addr: Address, compliance_signer: Address) -> Result<(), Error> {
        if env.storage().instance().has(&DataKey::Admin) { return Err(Error::AlreadyInitialized); }
        admin_addr.require_auth();
        env.storage().instance().set(&DataKey::Admin, &admin_addr);
        env.storage().instance().set(&DataKey::ComplianceSigner, &compliance_signer);
        env.storage().instance().set(&DataKey::Paused, &false);
        Ok(())
    }

    /// Creates an on-chain settlement intent. No fiat is represented here: `amount` is the
    /// exact Stellar USDC amount (stroops/asset base units) that must be escrowed after on-ramp.
    pub fn create(
        env: Env,
        id: BytesN<32>,
        payer: Address,
        source_partner: Address,
        destination_partner: Address,
        token: Address,
        amount: i128,
        source_currency: String,
        destination_currency: String,
        beneficiary_ref: BytesN<32>,
        quote_hash: BytesN<32>,
        expires_at: u64,
    ) -> Result<Settlement, Error> {
        ensure_live(&env)?;
        source_partner.require_auth();
        if amount <= 0 { return Err(Error::InvalidAmount); }
        if expires_at <= env.ledger().timestamp() { return Err(Error::InvalidExpiry); }
        let key = DataKey::Settlement(id.clone());
        if env.storage().persistent().has(&key) { return Err(Error::AlreadyExists); }
        let s = Settlement {
            id: id.clone(), payer, source_partner, destination_partner, token, amount,
            source_currency, destination_currency, beneficiary_ref, quote_hash, expires_at,
            status: SettlementStatus::AwaitingFunding,
            funded_at: 0, compliance_at: 0, released_at: 0,
        };
        write_settlement(&env, &s);
        event(&env, symbol_short!("created"), &id, s.status.clone());
        Ok(s)
    }

    /// Source partner deposits Stellar USDC into the contract after receiving/converting fiat.
    pub fn fund(env: Env, id: BytesN<32>) -> Result<Settlement, Error> {
        ensure_live(&env)?;
        let mut s = read_settlement(&env, &id)?;
        if s.status != SettlementStatus::AwaitingFunding { return Err(Error::InvalidState); }
        if env.ledger().timestamp() > s.expires_at { return Err(Error::Expired); }
        s.source_partner.require_auth();
        let client = token::Client::new(&env, &s.token);
        client.transfer(&s.source_partner, &env.current_contract_address(), &s.amount);
        s.status = SettlementStatus::Funded;
        s.funded_at = env.ledger().timestamp();
        write_settlement(&env, &s);
        event(&env, symbol_short!("funded"), &id, s.status.clone());
        Ok(s)
    }

    /// Called only by the dedicated compliance/transaction-monitoring signer after off-chain
    /// KYT/AML/rules screening. The evidence hash binds the decision to an external audit record.
    pub fn compliance_decision(env: Env, id: BytesN<32>, approved: bool, evidence_hash: BytesN<32>) -> Result<Settlement, Error> {
        ensure_live(&env)?;
        let signer = compliance(&env)?;
        signer.require_auth();
        let mut s = read_settlement(&env, &id)?;
        if s.status != SettlementStatus::Funded && s.status != SettlementStatus::Frozen { return Err(Error::InvalidState); }
        s.status = if approved { SettlementStatus::ComplianceApproved } else { SettlementStatus::ComplianceRejected };
        s.compliance_at = env.ledger().timestamp();
        write_settlement(&env, &s);
        env.events().publish((symbol_short!("xborder"), symbol_short!("screen"), id.clone()), (approved, evidence_hash));
        Ok(s)
    }

    /// Destination partner confirms beneficiary/off-ramp readiness. Release still requires an
    /// approved compliance decision; accepting before screening is deliberately disallowed.
    pub fn accept_destination(env: Env, id: BytesN<32>) -> Result<Settlement, Error> {
        ensure_live(&env)?;
        let mut s = read_settlement(&env, &id)?;
        if s.status != SettlementStatus::ComplianceApproved { return Err(Error::InvalidState); }
        if env.ledger().timestamp() > s.expires_at { return Err(Error::Expired); }
        s.destination_partner.require_auth();
        s.status = SettlementStatus::DestinationAccepted;
        write_settlement(&env, &s);
        event(&env, symbol_short!("accepted"), &id, s.status.clone());
        Ok(s)
    }

    /// Atomic release of escrowed USDC to the destination liquidity/off-ramp partner.
    pub fn release(env: Env, id: BytesN<32>) -> Result<Settlement, Error> {
        ensure_live(&env)?;
        let mut s = read_settlement(&env, &id)?;
        if s.status != SettlementStatus::DestinationAccepted { return Err(Error::InvalidState); }
        if env.ledger().timestamp() > s.expires_at { return Err(Error::Expired); }
        let client = token::Client::new(&env, &s.token);
        client.transfer(&env.current_contract_address(), &s.destination_partner, &s.amount);
        s.status = SettlementStatus::Released;
        s.released_at = env.ledger().timestamp();
        write_settlement(&env, &s);
        event(&env, symbol_short!("released"), &id, s.status.clone());
        Ok(s)
    }

    /// Refund after compliance rejection. Admin authorizes operationally; funds can only go back
    /// to the original source partner, never to an arbitrary address.
    pub fn refund_rejected(env: Env, id: BytesN<32>) -> Result<Settlement, Error> {
        let a = admin(&env)?; a.require_auth();
        let mut s = read_settlement(&env, &id)?;
        if s.status != SettlementStatus::ComplianceRejected { return Err(Error::InvalidState); }
        let client = token::Client::new(&env, &s.token);
        client.transfer(&env.current_contract_address(), &s.source_partner, &s.amount);
        s.status = SettlementStatus::Refunded;
        write_settlement(&env, &s);
        event(&env, symbol_short!("refunded"), &id, s.status.clone());
        Ok(s)
    }

    /// Permissionless timeout refund trigger prevents platform lock-in after SLA expiry.
    pub fn refund_expired(env: Env, id: BytesN<32>) -> Result<Settlement, Error> {
        let mut s = read_settlement(&env, &id)?;
        if env.ledger().timestamp() <= s.expires_at { return Err(Error::NotExpired); }
        match s.status {
            SettlementStatus::Funded | SettlementStatus::ComplianceApproved | SettlementStatus::DestinationAccepted | SettlementStatus::Frozen => {},
            _ => return Err(Error::InvalidState),
        }
        let client = token::Client::new(&env, &s.token);
        client.transfer(&env.current_contract_address(), &s.source_partner, &s.amount);
        s.status = SettlementStatus::Refunded;
        write_settlement(&env, &s);
        event(&env, symbol_short!("refunded"), &id, s.status.clone());
        Ok(s)
    }

    /// Emergency/compliance hold. Does not move funds.
    pub fn freeze(env: Env, id: BytesN<32>, reason_hash: BytesN<32>) -> Result<Settlement, Error> {
        let signer = compliance(&env)?; signer.require_auth();
        let mut s = read_settlement(&env, &id)?;
        match s.status {
            SettlementStatus::Funded | SettlementStatus::ComplianceApproved | SettlementStatus::DestinationAccepted => {},
            _ => return Err(Error::InvalidState),
        }
        s.status = SettlementStatus::Frozen;
        write_settlement(&env, &s);
        env.events().publish((symbol_short!("xborder"), symbol_short!("frozen"), id.clone()), reason_hash);
        Ok(s)
    }

    pub fn dispute(env: Env, id: BytesN<32>, reason_hash: BytesN<32>) -> Result<Settlement, Error> {
        let mut s = read_settlement(&env, &id)?;
        if s.status != SettlementStatus::Funded && s.status != SettlementStatus::ComplianceApproved && s.status != SettlementStatus::DestinationAccepted && s.status != SettlementStatus::Frozen { return Err(Error::InvalidState); }
        // Either corridor partner may open a dispute.
        // require_auth_for_args can be used by the client to make the exact actor explicit;
        // this API uses destination auth, while source can ask the compliance desk to freeze.
        s.destination_partner.require_auth();
        s.status = SettlementStatus::Disputed;
        write_settlement(&env, &s);
        env.events().publish((symbol_short!("xborder"), symbol_short!("dispute"), id.clone()), reason_hash);
        Ok(s)
    }

    pub fn set_paused(env: Env, paused: bool) -> Result<(), Error> {
        let a = admin(&env)?; a.require_auth();
        env.storage().instance().set(&DataKey::Paused, &paused);
        Ok(())
    }

    pub fn set_compliance_signer(env: Env, new_signer: Address) -> Result<(), Error> {
        let a = admin(&env)?; a.require_auth();
        env.storage().instance().set(&DataKey::ComplianceSigner, &new_signer);
        Ok(())
    }

    pub fn get(env: Env, id: BytesN<32>) -> Result<Settlement, Error> { read_settlement(&env, &id) }
}
