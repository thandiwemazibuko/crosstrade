<?php
// Reference application-layer states matching the Soroban contract.
// Fiat/KYC/beneficiary data stays in Laravel; only hashes/references are anchored on-chain.

enum SettlementStatus: string {
    case QUOTED = 'quoted';
    case AWAITING_FIAT = 'awaiting_fiat';
    case FIAT_RECEIVED = 'fiat_received';
    case USDC_CONVERTED = 'usdc_converted';
    case ONCHAIN_FUNDED = 'onchain_funded';
    case SCREENING = 'screening';
    case APPROVED = 'approved';
    case DESTINATION_ACCEPTED = 'destination_accepted';
    case USDC_RELEASED = 'usdc_released';
    case OFFRAMPING = 'offramping';
    case PAID_OUT = 'paid_out';
    case REFUNDED = 'refunded';
    case FROZEN = 'frozen';
    case DISPUTED = 'disputed';
}
