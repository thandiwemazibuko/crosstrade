/**
 * CrossTrade monitoring worker (reference implementation).
 * Protocol 23+ exposes a unified transfer event model via Stellar RPC getEvents.
 * Run this OUTSIDE Soroban: contracts cannot call sanctions/KYT APIs or inspect arbitrary history.
 *
 * Production flow:
 * 1. Subscribe/poll RPC for USDC transfer + CrossTrade contract events.
 * 2. Correlate contract settlement id, tx hash, source/destination addresses and amount.
 * 3. Apply deterministic rules + licensed KYT/sanctions provider(s).
 * 4. Persist full evidence off-chain (immutable/auditable store).
 * 5. SHA-256 canonical evidence JSON.
 * 6. Dedicated compliance signer invokes compliance_decision(id, approved, evidence_hash)
 *    or freeze(id, reason_hash). Never put PII or sanctions-provider payloads on-chain.
 */

const RULES = {
  maxSingleUsdc: 100_000,
  maxDailyUsdc: 250_000,
  maxHourlyTransfers: 20,
  requireKyc: true,
  blockSanctioned: true,
  blockHighRiskWallets: true,
};

export function evaluate(ctx) {
  const reasons = [];
  if (!ctx.kycVerified && RULES.requireKyc) reasons.push('KYC_REQUIRED');
  if (ctx.sanctionsHit && RULES.blockSanctioned) reasons.push('SANCTIONS_HIT');
  if (ctx.highRiskWallet && RULES.blockHighRiskWallets) reasons.push('HIGH_RISK_WALLET');
  if (ctx.amountUsdc > RULES.maxSingleUsdc) reasons.push('SINGLE_LIMIT');
  if (ctx.dailyUsdc > RULES.maxDailyUsdc) reasons.push('DAILY_LIMIT');
  if (ctx.hourlyTransfers > RULES.maxHourlyTransfers) reasons.push('VELOCITY_LIMIT');
  return { approved: reasons.length === 0, reasons };
}

// Wire RPC + your KYT provider in the Laravel queue/worker. This file intentionally contains
// no provider secrets and no fake AML implementation.
